# 동전게임 2.2 연결 테스트 앱 (1단계). 게임이 아니라 WebSocket 연결/지연만 확인합니다.
import asyncio
import json
import sys
import time
import pygame

SERVER = "wss://coingame-online.jhhj67.workers.dev/ws"   # 배포 후 주소가 다르면 여기만 고치세요
ROOM = "TEST"

try:
    from platform import window
    HAVE_JS = True
except Exception:
    window = None
    HAVE_JS = False

JS = """
window.cgq = [];
window.cgs = null;
window.cgConnect = function(url) {
  try {
    if (window.cgs) { try { window.cgs.close(); } catch (e) {} }
    var s = new WebSocket(url);
    window.cgs = s;
    s.onopen = function() { window.cgq.push("!open"); };
    s.onmessage = function(e) { window.cgq.push(String(e.data)); };
    s.onclose = function(e) { window.cgq.push("!close " + e.code); };
    s.onerror = function() { window.cgq.push("!error"); };
  } catch (err) { window.cgq.push("!exc " + err); }
};
window.cgSend = function(m) {
  if (window.cgs && window.cgs.readyState === 1) { window.cgs.send(m); return 1; }
  return 0;
};
window.cgPoll = function() { return window.cgq.length ? window.cgq.shift() : ""; };
window.cgClose = function() { if (window.cgs) { try { window.cgs.close(); } catch (e) {} } };
"""

pygame.init()
screen = pygame.display.set_mode((720, 420))
pygame.display.set_caption("WS test")
font = pygame.font.Font("font.ttf", 16)
big = pygame.font.Font("font.ttf", 22)

state = "대기 (C 키: 접속)"
log = []
recent = []   # 최근 핑 20개
stats = {"sent": 0, "recv": 0, "pong": 0, "rtt_last": 0, "rtt_sum": 0, "rtt_max": 0, "bytes_in": 0, "bytes_out": 0}
peer = "없음"
pings = {}
ping_id = 0
blast = False
rate_n = 0
rate_t = time.time()
rate_show = 0

def add_log(s):
    log.append(s)
    del log[:-8]

def now_ms():
    return int(time.time() * 1000)

def connect():
    global state
    if not HAVE_JS:
        state = "이 환경에서는 WebSocket을 쓸 수 없습니다 (웹에서만 가능)"
        return
    state = "접속 중..."
    window.cgConnect(SERVER + "?room=" + ROOM)

def send(s):
    if not HAVE_JS:
        return
    if window.cgSend(s):
        stats["sent"] += 1
        stats["bytes_out"] += len(s)

def handle(m):
    global state, peer
    if m.startswith("!"):
        if m == "!open":
            state = "접속됨"
        else:
            state = "끊김/오류: " + m
        add_log(m)
        return
    stats["recv"] += 1
    stats["bytes_in"] += len(m)
    head = m[:16].replace(" ", "")
    if head.startswith('{"t":"pong"'):
        j = json.loads(m)
        t0 = pings.pop(j.get("c"), None)
        if t0 is not None:
            r = now_ms() - t0
            stats["pong"] += 1
            stats["rtt_last"] = r
            stats["rtt_sum"] += r
            stats["rtt_max"] = max(stats["rtt_max"], r)
            recent.append(r)
            del recent[:-20]
    elif head.startswith('{"t":"hi"'):
        add_log("서버 인사: " + m)
    elif head.startswith('{"t":"joined"'):
        peer = "상대 접속함"; add_log("상대가 들어왔습니다")
    elif head.startswith('{"t":"left"'):
        peer = "상대 나감"; add_log("상대가 나갔습니다")
    else:
        pass

async def main():
    global ping_id, blast, rate_n, rate_t, rate_show, state
    if HAVE_JS:
        window.eval(JS)
    clock = pygame.time.Clock()
    last_ping = 0
    last_blast = 0
    while True:
        for e in pygame.event.get():
            if e.type == pygame.QUIT:
                return
            if e.type == pygame.KEYDOWN:
                if e.key == pygame.K_c:
                    connect()
                elif e.key == pygame.K_SPACE:
                    blast = not blast
                elif e.key == pygame.K_x:
                    if HAVE_JS: window.cgClose()
                elif e.key == pygame.K_r:
                    for k in stats: stats[k] = 0
                    del recent[:]
        t = time.time()
        if HAVE_JS:
            for _ in range(60):
                m = window.cgPoll()
                if not m:
                    break
                m = str(m)
                rate_n += 1
                handle(m)
        if t - rate_t >= 1:
            rate_show = rate_n; rate_n = 0; rate_t = t
        if state == "접속됨":
            if t - last_ping >= 1:
                last_ping = t
                ping_id += 1
                pings[ping_id] = now_ms()
                send(json.dumps({"t": "ping", "c": ping_id}, separators=(",", ":")))
            if blast and t - last_blast >= 1 / 15:   # 방장 스냅샷 흉내: 초당 15번, 약 600바이트
                last_blast = t
                send('{"t":"st","d":"' + ("x" * 560) + '"}')

        screen.fill((20, 24, 40))
        screen.blit(big.render("동전게임 2.2 연결 테스트", True, (255, 220, 80)), (16, 12))
        rows = [
            "서버: " + SERVER,
            "방: " + ROOM + "    상태: " + state,
            "상대: " + peer,
            "핑(왕복) 마지막 %d ms / 최근20개 평균 %d ms / 최근20개 최대 %d ms" % (stats["rtt_last"], (sum(recent) // len(recent)) if recent else 0, max(recent) if recent else 0),
            "보냄 %d개 (%d B) / 받음 %d개 (%d B) / 최근 1초 수신 %d개" % (stats["sent"], stats["bytes_out"], stats["recv"], stats["bytes_in"], rate_show),
            "스냅샷 흉내 전송(초당 15개): " + ("켜짐" if blast else "꺼짐"),
        ]
        y = 56
        for r in rows:
            screen.blit(font.render(r, True, (230, 230, 230)), (16, y)); y += 26
        screen.blit(font.render("C: 접속   스페이스: 스냅샷 흉내 전송   X: 끊기   R: 숫자 초기화", True, (140, 200, 255)), (16, y + 6))
        y += 40
        for l in log:
            screen.blit(font.render(l[:80], True, (170, 170, 170)), (16, y)); y += 22
        if not HAVE_JS:
            screen.blit(font.render("(웹이 아닌 환경: JS 연결 없음)", True, (255, 120, 120)), (16, 390))
        pygame.display.flip()
        clock.tick(60)
        await asyncio.sleep(0)

asyncio.run(main())
